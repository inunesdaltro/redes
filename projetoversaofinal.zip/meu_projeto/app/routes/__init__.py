# app/routes/__init__.py

"""
Pacote de rotas da aplicação.
Os arquivos de rota são importados aqui.
"""
