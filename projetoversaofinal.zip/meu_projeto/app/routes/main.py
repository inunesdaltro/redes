from flask import Blueprint, request, jsonify, render_template, redirect, url_for, session
from app.models import db, User, Doctor, Patient, Biomedico, Slot
from datetime import datetime, date, time, timedelta

main = Blueprint('main', __name__)

# Rota Home: renderiza a página inicial
@main.route('/', methods=['GET'])
def home_page():
    return render_template('home.html')

# Rota de login
@main.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    
    email = request.form.get('email')
    password = request.form.get('password')
    # Comparação simples para demonstração – use hashing em produção
    user = User.query.filter_by(email=email, password=password).first()
    if user:
        session['user_id'] = user.id
        session['role'] = user.role
        return redirect(url_for('main.schedule_appointment'))
    else:
        return render_template('login.html', error="Invalid email or password")

# Rota de logout
@main.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('main.home_page'))

# Rota para registro de usuário
@main.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    
    data = request.form
    email = data.get('email')
    password = data.get('password')
    confirm_password = data.get('confirm_password')
    role = data.get('role')
    
    if not email or not password or not role:
        return jsonify({"error": "Missing required fields"}), 400
    
    if password != confirm_password:
        return render_template('register.html', error="Passwords do not match"), 400
    
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        return render_template('register.html', error="Email already registered"), 400
    
    new_user = User(name=data.get('name'), email=email, password=password, role=role)
    db.session.add(new_user)
    db.session.commit()
    
    # Redireciona conforme o role do usuário
    if role == 'medico':
        return redirect(url_for('main.register_doctor_page', user_id=new_user.id))
    elif role == 'biomédico':
        return redirect(url_for('main.register_biomedico_page', user_id=new_user.id))
    elif role == 'paciente':
        return redirect(url_for('main.register_patient_page'))
    elif role == 'admin':
        return redirect(url_for('main.home_page'))
    else:
        return render_template('register.html', error="Invalid role selected")

# Rota para registro de paciente
@main.route('/register_patient', methods=['GET', 'POST'])
def register_patient_page():
    if request.method == 'GET':
        return render_template('register_patient.html')
    
    date_of_birth_str = request.form.get('date_of_birth')
    medical_history = request.form.get('medical_history', "")
    try:
        dob = datetime.strptime(date_of_birth_str, '%Y-%m-%d').date()
    except Exception as ex:
        return f"Data de nascimento inválida: {ex}", 400
    new_patient = Patient(date_of_birth=dob, medical_history=medical_history)
    db.session.add(new_patient)
    db.session.commit()
    return redirect(url_for('main.home_page'))

# Rota para registro de médico
@main.route('/register_doctor', methods=['GET', 'POST'])
def register_doctor_page():
    if request.method == 'GET':
        user_id = request.args.get('user_id')
        crm = request.args.get('crm', '')
        return render_template('register_doctor.html', user_id=user_id, crm=crm)
    
    user_id = request.form.get('user_id')
    specialty = request.form.get('specialty')
    crm = request.form.get('crm')
    available_hours = request.form.get('available_hours')
    doctor = Doctor(id=user_id, specialty=specialty, crm=crm)
    if available_hours:
        doctor.available_hours = available_hours
    db.session.add(doctor)
    db.session.commit()
    return redirect(url_for('main.home_page'))

# Rota para registro de biomédico
@main.route('/register_biomedico', methods=['GET', 'POST'])
def register_biomedico_page():
    if request.method == 'GET':
        user_id = request.args.get('user_id')
        return render_template('register_biomedico.html', user_id=user_id)
    
    user_id = request.form.get('user_id')
    crbm = request.form.get('crbm')
    available_hours = request.form.get('available_hours')
    biomedico = Biomedico(id=user_id, crbm=crbm)
    if available_hours:
        biomedico.available_hours = available_hours
    db.session.add(biomedico)
    db.session.commit()
    return redirect(url_for('main.home_page'))

# Rota para visualizar a página de agendamento (calendário estilo Excel)
@main.route('/schedule_appointment', methods=['GET'])
def schedule_appointment():
    doctors = Doctor.query.all()
    biomedicos = Biomedico.query.all()
    return render_template('schedule_appointment.html', doctors=doctors, biomedicos=biomedicos)

# --- ENDPOINTS PARA O CALENDÁRIO ---

# Endpoint para retornar os médicos (usuários com role "medico")
@main.route('/api/get_doctors', methods=['GET'])
def get_doctors():
    doctors = User.query.filter_by(role='medico').all()
    doc_list = [{"id": doc.id, "name": doc.name} for doc in doctors]
    return jsonify({"doctors": doc_list})

# Endpoint para listar os slots disponíveis filtrando por doctor_id e intervalo de datas (semana)
@main.route('/api/available_slots', methods=['GET'])
def get_available_slots():
    """Retorna slots disponíveis e agendados, incluindo paciente e histórico médico."""
    try:
        doctor_id = request.args.get('doctor_id')
        start_str = request.args.get('start')
        end_str = request.args.get('end')
        query = Slot.query

        if doctor_id:
            query = query.filter(Slot.doctor_id == int(doctor_id))

        if start_str and end_str:
            try:
                start_date = datetime.strptime(start_str, "%Y-%m-%d").date()
                end_date = datetime.strptime(end_str, "%Y-%m-%d").date()
                query = query.filter(Slot.date >= start_date, Slot.date <= end_date)
            except Exception as ex:
                print("Erro ao processar datas:", ex)

        slots = query.all()
        slots_list = []

        for slot in slots:
            doctor_name, doctor_specialty, patient_name, patient_history = "", "", "", ""

            if slot.doctor_id:
                doctor_rec = Doctor.query.get(slot.doctor_id)
                if doctor_rec:
                    doctor_specialty = doctor_rec.specialty
                doctor_user = User.query.get(slot.doctor_id)
                if doctor_user:
                    doctor_name = doctor_user.name

            if slot.patient_id:
                patient = Patient.query.get(slot.patient_id)
                if patient:
                    patient_name = User.query.get(patient.id).name if User.query.get(patient.id) else ""
                    patient_history = patient.medical_history

            slots_list.append({
                "id": slot.id,
                "date": slot.date.isoformat(),
                "time": slot.time.strftime("%H:%M"),
                "status": slot.status,
                "doctor_name": doctor_name,
                "doctor_specialty": doctor_specialty,
                "patient_name": patient_name,
                "patient_history": patient_history
            })

        return jsonify({"slots": slots_list})
    except Exception as e:
        print("Erro ao buscar slots:", e)
        return jsonify({"error": str(e)}), 500

# Endpoint para registrar agendamento (para pacientes)
@main.route('/api/register_appointment', methods=['POST'])
def register_appointment():
    """
    Recebe um JSON com:
       { "appointments": [ <slot_id1>, <slot_id2>, ... ] }
    """
    try:
        data = request.json
        appointments = data.get('appointments', [])
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({"error": "Usuário não autenticado."}), 401
        user = User.query.get(user_id)
        if not user or user.role != 'paciente':
            return jsonify({"error": "Somente pacientes podem agendar consultas."}), 403

        for appointment in appointments:
            slot_id = appointment
            slot = Slot.query.get(slot_id)
            if not slot:
                return jsonify({"error": f"Slot com ID {slot_id} não encontrado"}), 404
            if slot.status == "scheduled":
                return jsonify({"error": f"Horário já agendado para o slot {slot_id}"}), 400
            
            slot.status = "scheduled"
            slot.patient_name = user.name
            db.session.add(slot)
        db.session.commit()
        return jsonify({"message": "Appointments registered successfully"}), 200
    except Exception as e:
        print(f"Error registering appointment: {e}")
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500

# Endpoint para que o médico selecione seus slots de atendimento
@main.route('/api/select_slots', methods=['POST'])
def select_slots():
    """
    Recebe um JSON com:
       { "slots": [ { "date": "YYYY-MM-DD", "time": "HH:MM" }, ... ] }
    """
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"error": "Usuário não autenticado."}), 401
    user = User.query.get(user_id)
    if not user or user.role != 'medico':
        return jsonify({"error": "Somente médicos podem selecionar slots."}), 403
    
    data = request.json
    selected_slots = data.get('slots', [])
    if not selected_slots:
        return jsonify({"error": "Nenhum slot informado."}), 400

    for slot_data in selected_slots:
        slot_date_str = slot_data.get("date")
        slot_time_str = slot_data.get("time")
        try:
            slot_date = datetime.strptime(slot_date_str, "%Y-%m-%d").date()
            slot_time = datetime.strptime(slot_time_str, "%H:%M").time()
        except Exception as ex:
            return jsonify({"error": f"Formato de data/hora inválido: {ex}"}), 400
        slot = Slot.query.filter_by(date=slot_date, time=slot_time).first()
        if not slot:
            slot = Slot(date=slot_date, time=slot_time, status="available", doctor_id=user_id)
            db.session.add(slot)
        else:
            if slot.status != "scheduled":
                slot.doctor_id = user_id
                slot.status = "available"
    db.session.commit()
    return jsonify({"message": "Slots atualizados com sucesso."}), 200

# Endpoint para criar slots automaticamente (restrito para admin)
@main.route('/api/create_slots', methods=['POST'])
def create_slots_endpoint():
    if 'role' not in session or session['role'] != 'admin':
        return jsonify({"error": "Acesso negado (somente admin)"}), 403
    data = request.json or {}
    start_str = data.get('start')
    end_str = data.get('end')
    if start_str and end_str:
        start_date = datetime.strptime(start_str, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_str, '%Y-%m-%d').date()
    else:
        start_date = date.today()
        end_date = start_date + timedelta(days=7)
    current_day = start_date
    created_count = 0
    while current_day <= end_date:
        if current_day.weekday() < 6:
            created_count += create_50min_slots(current_day, time(8, 0), time(12, 0))
            created_count += create_50min_slots(current_day, time(14, 0), time(18, 0))
        current_day += timedelta(days=1)
    db.session.commit()
    return jsonify({
        "message": f"Slots criados/atualizados: {created_count}",
        "from": start_date.isoformat(),
        "to": end_date.isoformat()
    }), 200

# Função auxiliar: cria slots de 50 minutos (com 10 minutos de intervalo)
def create_50min_slots(day_date, start_time, end_time):
    created = 0
    current_dt = datetime.combine(day_date, start_time)
    limit_dt = datetime.combine(day_date, end_time)
    while current_dt < limit_dt:
        slot_date = current_dt.date()
        slot_time = current_dt.time()
        existing_slot = Slot.query.filter_by(date=slot_date, time=slot_time).first()
        if not existing_slot:
            new_slot = Slot(date=slot_date, time=slot_time, status="available")
            db.session.add(new_slot)
            created += 1
        current_dt += timedelta(minutes=50)
    return created

# Rota de sucesso (opcional)
@main.route('/success', methods=['GET'])
def success():
    return render_template('success.html')
