from app import db
from datetime import date, time

class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    # role pode ser 'admin', 'medico', 'paciente' ou 'biomédico'
    role = db.Column(db.String(10), nullable=False)

    def __repr__(self):
        return f"<User {self.id} {self.email} ({self.role})>"

class Doctor(db.Model):
    __tablename__ = "doctors"

    id = db.Column(db.Integer, primary_key=True)
    specialty = db.Column(db.String(100), nullable=False)
    crm = db.Column(db.String(20), nullable=False)
    # Para associar a um usuário, descomente a linha abaixo:
    # user_id = db.Column(db.Integer, db.ForeignKey('users.id'))

class Patient(db.Model):
    __tablename__ = "patients"

    id = db.Column(db.Integer, primary_key=True)
    date_of_birth = db.Column(db.Date, nullable=False)
    medical_history = db.Column(db.Text)
    # Para associar a um usuário, descomente a linha abaixo:
    # user_id = db.Column(db.Integer, db.ForeignKey('users.id'))

class Biomedico(db.Model):
    __tablename__ = "biomedicos"

    id = db.Column(db.Integer, primary_key=True)
    crbm = db.Column(db.String(20), nullable=False)
    # Para associar a um usuário, descomente a linha abaixo:
    # user_id = db.Column(db.Integer, db.ForeignKey('users.id'))

class Slot(db.Model):
    __tablename__ = "slots"

    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)    # Ex: 2025-01-20
    time = db.Column(db.Time, nullable=False)      # Ex: 09:00:00
    status = db.Column(db.String(20), default="available")  # "available" ou "scheduled"
    patient_name = db.Column(db.String(100))         # Preenchido se agendado

    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'), nullable=True)
    biomedico_id = db.Column(db.Integer, db.ForeignKey('biomedicos.id'), nullable=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'), nullable=True)

    doctor = db.relationship('Doctor', backref=db.backref('slots', lazy=True))
    biomedico = db.relationship('Biomedico', backref=db.backref('slots', lazy=True))
    patient = db.relationship('Patient', backref=db.backref('slots', lazy=True))
