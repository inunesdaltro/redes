from datetime import date, time, timedelta
from app import create_app, db
from app.models import User, Slot
from app.routes.main import create_50min_slots

app = create_app()

def create_admin():
    """Verifica se já existe um usuário admin. Se não, cria um admin padrão."""
    admin = User.query.filter_by(role='admin').first()
    if not admin:
        admin = User(
            name="administração",
            email="admin@ourhealth.com",
            password="CareGiveIniciative",  # Em produção, utilize hashing!
            role="admin"
        )
        db.session.add(admin)
        db.session.commit()
        print("Usuário administrador criado com sucesso.")
    else:
        print("Usuário administrador já existe.")

def auto_create_slots():
    """
    Cria slots para a semana atual (segunda a sábado) nos horários:
    08:00-12:00 e 14:00-18:00, com intervalos de 50 minutos (com 10 min de intervalo).
    """
    with app.app_context():
        base_date = date.today()
        end_date = base_date + timedelta(days=7)
        current_day = base_date
        created_count = 0
        while current_day <= end_date:
            if current_day.weekday() < 6:
                created_count += create_50min_slots(current_day, time(8, 0), time(12, 0))
                created_count += create_50min_slots(current_day, time(14, 0), time(18, 0))
            current_day += timedelta(days=1)
        db.session.commit()
        print(f"[auto_create_slots] Slots criados/atualizados: {created_count}")

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        print("[run.py] Banco de dados criado com sucesso!")
        create_admin()  # Cria um usuário admin, se necessário.
        # Para gerar os slots automaticamente ao iniciar, descomente a linha abaixo:
        # auto_create_slots()
    app.run(host='0.0.0.0', port=5000, debug=True)
