from app import db

class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    # role: "admin", "medico", "paciente" ou "biomédico"
    role = db.Column(db.String(10), nullable=False)

    def __repr__(self):
        return f"<User {self.id} {self.email} ({self.role})>"

class Doctor(db.Model):
    __tablename__ = "doctors"
    # Relação one-to-one: o id é o mesmo do usuário correspondente
    id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    specialty = db.Column(db.String(100), nullable=False)
    crm = db.Column(db.String(20), nullable=False)
    user = db.relationship('User', backref=db.backref('doctor_profile', uselist=False))

class Patient(db.Model):
    __tablename__ = "patients"
    # Relação one-to-one: o id é o mesmo do usuário correspondente
    id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    date_of_birth = db.Column(db.Date, nullable=False)
    medical_history = db.Column(db.Text)
    user = db.relationship('User', backref=db.backref('patient_profile', uselist=False))

class Biomedico(db.Model):
    __tablename__ = "biomedicos"
    # Relação one-to-one: o id é o mesmo do usuário correspondente
    id = db.Column(db.Integer, db.ForeignKey('users.id'), primary_key=True)
    crbm = db.Column(db.String(20), nullable=False)
    user = db.relationship('User', backref=db.backref('biomedico_profile', uselist=False))

class Slot(db.Model):
    __tablename__ = "slots"

    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)    # Ex.: 2025-01-20
    time = db.Column(db.Time, nullable=False)      # Ex.: 09:00:00
    status = db.Column(db.String(20), default="available")  # "available" ou "scheduled"
    patient_name = db.Column(db.String(100))         # Preenchido se agendado

    # Cada slot é específico para um profissional:
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'), nullable=True)
    biomedico_id = db.Column(db.Integer, db.ForeignKey('biomedicos.id'), nullable=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'), nullable=True)

    doctor = db.relationship('Doctor', backref=db.backref('slots', lazy=True))
    biomedico = db.relationship('Biomedico', backref=db.backref('slots', lazy=True))
    patient = db.relationship('Patient', backref=db.backref('slots', lazy=True))
