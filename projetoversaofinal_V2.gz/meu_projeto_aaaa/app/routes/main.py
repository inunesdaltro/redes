from flask import Blueprint, request, jsonify, render_template, redirect, url_for, session
from app.models import db, User, Doctor, Patient, Biomedico, Slot
from datetime import datetime, date, time, timedelta

main = Blueprint('main', __name__)

# Página inicial
@main.route('/', methods=['GET'])
def home_page():
    return render_template('home.html')

# Login
@main.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    email = request.form.get('email')
    password = request.form.get('password')
    user = User.query.filter_by(email=email, password=password).first()
    if user:
        session['user_id'] = user.id
        session['role'] = user.role
        return redirect(url_for('main.schedule_appointment'))
    else:
        return render_template('login.html', error="Invalid email or password")

# Logout
@main.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('main.home_page'))

# Registro de usuário (formulário geral)
@main.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    data = request.form
    email = data.get('email')
    password = data.get('password')
    confirm_password = data.get('confirm_password')
    role = data.get('role')
    if not email or not password or not role:
        return jsonify({"error": "Missing required fields"}), 400
    if password != confirm_password:
        return render_template('register.html', error="Passwords do not match"), 400
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        return render_template('register.html', error="Email already registered"), 400
    new_user = User(name=data.get('name'), email=email, password=password, role=role)
    db.session.add(new_user)
    db.session.commit()
    if role == 'medico':
        return redirect(url_for('main.register_doctor_page', user_id=new_user.id))
    elif role == 'biomédico':
        return redirect(url_for('main.register_biomedico_page', user_id=new_user.id))
    elif role == 'paciente':
        return redirect(url_for('main.register_patient_page', user_id=new_user.id))
    elif role == 'admin':
        return redirect(url_for('main.home_page'))
    else:
        return render_template('register.html', error="Invalid role selected")

# Registro de paciente
@main.route('/register_patient', methods=['GET', 'POST'])
def register_patient_page():
    if request.method == 'GET':
        return render_template('register_patient.html', user_id=request.args.get('user_id'))
    user_id = request.form.get('user_id')
    date_of_birth_str = request.form.get('date_of_birth')
    medical_history = request.form.get('medical_history', "")
    try:
        dob = datetime.strptime(date_of_birth_str, '%Y-%m-%d').date()
    except Exception as ex:
        return f"Invalid date: {ex}", 400
    new_patient = Patient(id=user_id, date_of_birth=dob, medical_history=medical_history)
    db.session.add(new_patient)
    db.session.commit()
    return redirect(url_for('main.home_page'))

# Registro de médico
@main.route('/register_doctor', methods=['GET', 'POST'])
def register_doctor_page():
    if request.method == 'GET':
        user_id = request.args.get('user_id')
        crm = request.args.get('crm', '')
        return render_template('register_doctor.html', user_id=user_id, crm=crm)
    user_id = request.form.get('user_id')
    specialty = request.form.get('specialty')
    crm = request.form.get('crm')
    available_hours = request.form.get('available_hours')
    new_doctor = Doctor(id=user_id, specialty=specialty, crm=crm)
    if available_hours:
        new_doctor.available_hours = available_hours
    db.session.add(new_doctor)
    db.session.commit()
    return redirect(url_for('main.home_page'))

# Registro de biomédico
@main.route('/register_biomedico', methods=['GET', 'POST'])
def register_biomedico_page():
    if request.method == 'GET':
        user_id = request.args.get('user_id')
        return render_template('register_biomedico.html', user_id=user_id)
    user_id = request.form.get('user_id')
    crbm = request.form.get('crbm')
    available_hours = request.form.get('available_hours')
    new_biomedico = Biomedico(id=user_id, crbm=crbm)
    if available_hours:
        new_biomedico.available_hours = available_hours
    db.session.add(new_biomedico)
    db.session.commit()
    return redirect(url_for('main.home_page'))

# Página de agendamento (calendário)
@main.route('/schedule_appointment', methods=['GET'])
def schedule_appointment():
    return render_template('schedule_appointment.html')

# --- ENDPOINTS PARA O CALENDÁRIO ---

@main.route('/api/get_doctors', methods=['GET'])
def get_doctors():
    medicos = User.query.filter_by(role='medico').all()
    biomedicos = User.query.filter_by(role='biomédico').all()
    professionals = medicos + biomedicos
    doc_list = [{"id": prof.id, "name": prof.name} for prof in professionals]
    return jsonify({"doctors": doc_list})

@main.route('/api/available_slots', methods=['GET'])
def get_available_slots():
    try:
        doctor_id = request.args.get('doctor_id')
        start_str = request.args.get('start')
        end_str = request.args.get('end')
        query = Slot.query
        if doctor_id:
            query = query.filter((Slot.doctor_id == int(doctor_id)) | (Slot.biomedico_id == int(doctor_id)))
        if start_str and end_str:
            try:
                start_date = datetime.strptime(start_str, "%Y-%m-%d").date()
                end_date = datetime.strptime(end_str, "%Y-%m-%d").date()
                query = query.filter(Slot.date >= start_date, Slot.date <= end_date)
            except Exception as ex:
                print("Error processing dates:", ex)
        slots = query.all()
        slots_list = []
        for slot in slots:
            doctor_name, doctor_specialty = "", ""
            patient_name, patient_history = "", ""
            if slot.doctor_id:
                doc = Doctor.query.get(slot.doctor_id)
                if doc:
                    doctor_specialty = doc.specialty
                doc_user = User.query.get(slot.doctor_id)
                if doc_user:
                    doctor_name = doc_user.name
            elif slot.biomedico_id:
                bio = Biomedico.query.get(slot.biomedico_id)
                bio_user = User.query.get(slot.biomedico_id)
                if bio_user:
                    doctor_name = bio_user.name
            if slot.patient_id:
                patient = Patient.query.get(slot.patient_id)
                if patient and patient.user:
                    patient_name = patient.user.name
                    patient_history = patient.medical_history
            slots_list.append({
                "id": slot.id,
                "date": slot.date.isoformat(),
                "time": slot.time.strftime("%H:%M"),
                "status": slot.status,
                "doctor_id": slot.doctor_id if slot.doctor_id else slot.biomedico_id,
                "doctor_name": doctor_name,
                "doctor_specialty": doctor_specialty,
                "patient_name": patient_name,
                "patient_history": patient_history
            })
        return jsonify({"slots": slots_list})
    except Exception as e:
        print("Error fetching slots:", e)
        return jsonify({"error": str(e)}), 500

@main.route('/api/register_appointment', methods=['POST'])
def register_appointment():
    try:
        data = request.json
        appointments = data.get('appointments', [])
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({"error": "Usuário não autenticado."}), 401
        user = User.query.get(user_id)
        if not user or user.role != 'paciente':
            return jsonify({"error": "Somente pacientes podem agendar consultas."}), 403
        for appointment in appointments:
            slot = Slot.query.get(appointment)
            if not slot:
                return jsonify({"error": f"Slot com ID {appointment} não encontrado"}), 404
            if slot.status == "scheduled":
                return jsonify({"error": f"Horário já agendado para o slot {appointment}"}), 400
            slot.status = "scheduled"
            slot.patient_name = user.name
            slot.patient_id = user.id
            db.session.add(slot)
        db.session.commit()
        return jsonify({"message": "Appointments registered successfully"}), 200
    except Exception as e:
        print(f"Error registering appointment: {e}")
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500

@main.route('/api/select_slots', methods=['POST'])
def select_slots():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"error": "Usuário não autenticado."}), 401
    user = User.query.get(user_id)
    if not user or user.role not in ['medico', 'biomédico']:
        return jsonify({"error": "Somente médicos ou biomédicos podem selecionar slots."}), 403
    data = request.json
    selected_slots = data.get('slots', [])
    if not selected_slots:
        return jsonify({"error": "Nenhum slot informado."}), 400
    for slot_data in selected_slots:
        slot_date_str = slot_data.get("date")
        slot_time_str = slot_data.get("time")
        try:
            slot_date = datetime.strptime(slot_date_str, "%Y-%m-%d").date()
            slot_time = datetime.strptime(slot_time_str, "%H:%M").time()
        except Exception as ex:
            return jsonify({"error": f"Formato de data/hora inválido: {ex}"}), 400
        if user.role == 'medico':
            slot = Slot.query.filter_by(date=slot_date, time=slot_time, doctor_id=user_id).first()
        else:
            slot = Slot.query.filter_by(date=slot_date, time=slot_time, biomedico_id=user_id).first()
        if not slot:
            if user.role == 'medico':
                slot = Slot(date=slot_date, time=slot_time, status="available", doctor_id=user_id)
            else:
                slot = Slot(date=slot_date, time=slot_time, status="available", biomedico_id=user_id)
            db.session.add(slot)
        else:
            if slot.status != "scheduled":
                if user.role == 'medico':
                    slot.doctor_id = user_id
                else:
                    slot.biomedico_id = user_id
                slot.status = "available"
    db.session.commit()
    return jsonify({"message": "Slots atualizados com sucesso."}), 200

@main.route('/api/create_slots', methods=['POST'])
def create_slots_endpoint():
    if 'role' not in session or session['role'] != 'admin':
        return jsonify({"error": "Acesso negado (somente admin)"}), 403
    data = request.json or {}
    start_str = data.get('start')
    end_str = data.get('end')
    if start_str and end_str:
        start_date = datetime.strptime(start_str, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_str, '%Y-%m-%d').date()
    else:
        start_date = date.today()
        end_date = start_date + timedelta(days=7)
    current_day = start_date
    created_count = 0
    while current_day <= end_date:
        if current_day.weekday() < 6:
            created_count += create_50min_slots(current_day, time(8, 0), time(12, 0))
            created_count += create_50min_slots(current_day, time(14, 0), time(18, 0))
        current_day += timedelta(days=1)
    db.session.commit()
    return jsonify({
        "message": f"Slots criados/atualizados: {created_count}",
        "from": start_date.isoformat(),
        "to": end_date.isoformat()
    }), 200

def create_50min_slots(day_date, start_time, end_time):
    created = 0
    current_dt = datetime.combine(day_date, start_time)
    limit_dt = datetime.combine(day_date, end_time)
    while current_dt < limit_dt:
        slot_date = current_dt.date()
        slot_time = current_dt.time()
        existing_slot = Slot.query.filter_by(date=slot_date, time=slot_time).first()
        if not existing_slot:
            new_slot = Slot(date=slot_date, time=slot_time, status="available")
            db.session.add(new_slot)
            created += 1
        current_dt += timedelta(minutes=50)
    return created

@main.route('/success', methods=['GET'])
def success():
    return render_template('success.html')
